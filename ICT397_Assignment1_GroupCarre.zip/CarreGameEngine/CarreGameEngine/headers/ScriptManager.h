#include "lua.hpp"
#pragma comment(lib,"lua5.1.lib")

int loadScript();
