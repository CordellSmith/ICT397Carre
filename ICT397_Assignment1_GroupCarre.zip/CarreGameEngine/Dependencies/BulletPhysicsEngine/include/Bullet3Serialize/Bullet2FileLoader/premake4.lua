	project "Bullet2FileLoader"
		
	kind "StaticLib"
	
	includedirs {
		"../../../src"
	}
	 
	files {
		"**.cpp",
		"**.h"
	}