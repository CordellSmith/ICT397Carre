	project "Bullet3Common"

	language "C++"
				
	kind "StaticLib"
		
	includedirs {".."}

	files {
		"*.cpp",
		"*.h"
	}
